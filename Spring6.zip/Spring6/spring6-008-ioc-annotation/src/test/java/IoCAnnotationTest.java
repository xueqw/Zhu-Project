import bean.Order;
import bean.Student;
import bean.User;
import bean.Vip;
import bean3.MyDataSource;
import cn.powernode.Spring6Config;
import cn.powernode.service.StudentService;
import org.junit.Test;
import org.powernode.Service.OrderService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.annotation.Annotation;

public class IoCAnnotationTest {
    @Test
    public void testNoXML(){
        AnnotationConfigApplicationContext annotationConfigApplicationContext = new AnnotationConfigApplicationContext(Spring6Config.class);
        StudentService studentService = annotationConfigApplicationContext.getBean("studentService", StudentService.class);
        studentService.deleteStudent();
    }

    @Test
    public void testResource(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-resource.xml");
        StudentService studentService = applicationContext.getBean("studentService", StudentService.class);
        studentService.deleteStudent();
    }

    @Test
    public void testAutowired(){
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("spring-autowired.xml");
        org.powernode.Service.OrderService orderService = classPathXmlApplicationContext.getBean("orderService", org.powernode.Service.OrderService.class);
        orderService.generate();
    }

    @Test
    public void testDIByAnnotation(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-di-annotation.xml");
        MyDataSource bean = applicationContext.getBean("myDataSource", MyDataSource.class);
        System.out.println(bean);
    }

    @Test
    public void testBeanConponent(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        User userBean = applicationContext.getBean("userBean", User.class);
        System.out.println(userBean);
        Vip vipBean = applicationContext.getBean("vipBean", Vip.class);
        System.out.println(vipBean);
        Order orderBean = applicationContext.getBean("orderBean", Order.class);
        Student studentBean = applicationContext.getBean("studentBean", Student.class);

    }
}
