package bean;

import org.springframework.stereotype.Controller;

@Controller(value = "vipBean")
public class Vip {
}
