package bean;

import org.springframework.stereotype.Service;

@Service(value = "orderBean")
public class Order {
}
