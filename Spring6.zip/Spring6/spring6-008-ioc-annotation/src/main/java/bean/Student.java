package bean;

import org.springframework.stereotype.Repository;

@Repository(value = "studentBean")
public class Student {
}
