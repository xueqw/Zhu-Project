package org.powernode.Service;

import org.powernode.dao.OrderDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderService")
public class OrderService {
    // Autowired不需要指定任何属性，直接使用这个注解即可
    // 注解的作用是根据ByType自动装配
    @Autowired
    private OrderDao orderDao;


    public void generate(){
        orderDao.insert();
    }
}
