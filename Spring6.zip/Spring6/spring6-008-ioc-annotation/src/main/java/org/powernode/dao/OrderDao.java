package org.powernode.dao;

public interface OrderDao {
    void insert();
}
