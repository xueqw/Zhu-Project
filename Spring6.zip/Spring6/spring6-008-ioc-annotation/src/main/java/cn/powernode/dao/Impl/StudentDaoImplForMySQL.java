package cn.powernode.dao.Impl;

import cn.powernode.dao.StudentDao;
import org.springframework.stereotype.Repository;

@Repository("StudentDaoImplForMySQL")
public class StudentDaoImplForMySQL implements StudentDao {
    @Override
    public void deleteById() {
        System.out.println("mysql数据库正在删除学生信息");
    }
}
