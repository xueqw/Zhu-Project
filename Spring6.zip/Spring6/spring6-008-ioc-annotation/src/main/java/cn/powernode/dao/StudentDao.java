package cn.powernode.dao;

public interface StudentDao {
    void deleteById();
}
