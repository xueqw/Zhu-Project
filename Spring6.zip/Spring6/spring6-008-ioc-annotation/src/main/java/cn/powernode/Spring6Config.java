package cn.powernode;

// 编写一个类，代替Spring框架的配置文件

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"cn.powernode.dao","cn.powernode.service"})
public class Spring6Config {

}
