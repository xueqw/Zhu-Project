package org.myspringframework.core;

/**
 * myspring上下文接口
 */
public interface ApplicationContext {
    Object getBean(String beanName);
}
