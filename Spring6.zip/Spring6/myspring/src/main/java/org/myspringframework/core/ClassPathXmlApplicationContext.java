package org.myspringframework.core;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClassPathXmlApplicationContext implements ApplicationContext {
    private static final Logger logger = LoggerFactory.getLogger(ClassPathXmlApplicationContext.class);

    private Map<String, Object> singletonObjects = new HashMap<>();

    /**
     * 解析myspring文件，初始化Bean对象
     *
     * @param configLocation
     */
    public ClassPathXmlApplicationContext(String configLocation) {
        try {
            // 解析myspring.xml，实例化Bean
            SAXReader reader = new SAXReader();
            // 获取一个输入流，指向配置文件
            InputStream resourceAsStream = ClassLoader.getSystemClassLoader().getResourceAsStream(configLocation);
            // 读文件
            Document document = reader.read(resourceAsStream);
            // 获取所有Bean标签
            List<Node> nodes = document.selectNodes("//bean");
            // 遍历Bean标签
            nodes.forEach(node -> {
                try {
                    //System.out.println(node);
                    // 向下转型的目的是为了使用element接口里更丰富的方法
                    Element beanElt = (Element) node;
                    // 获取id
                    String id = beanElt.attributeValue("id");
                    // 获取className
                    String className = beanElt.attributeValue("class");
                    logger.info("beanName=" + id);
                    logger.info("beanClassName="+className);
                    // 用反射机制创建对象，将其放到Map集合中，提前曝光
                    Class<?> aClass = Class.forName(className);
                    Constructor<?> defaultCon = aClass.getDeclaredConstructor();
                    Object bean = defaultCon.newInstance();
                    singletonObjects.put(id,bean);
                    logger.info(singletonObjects.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            nodes.forEach(node -> {
                try {
                    Element beanElt = (Element) node;
                    // 获取id
                    String id = beanElt.attributeValue("id");
                    // 获取className
                    String className = beanElt.attributeValue("class");
                    // 获取Class
                    Class<?> aClass = Class.forName(className);
                    // 获取该bean标签下所有属性property标签
                    List<Element> properties = beanElt.elements("property");
                    properties.forEach(property->{
                        // 获取属性名
                        try {
                            String propertyName = property.attributeValue("name");
                            // 获取属性类型
                            Field field = aClass.getDeclaredField(propertyName);
                            logger.info(""+propertyName);
                            // 获取set方法名
                            String setMethodName = "set" + propertyName.toUpperCase().charAt(0) + propertyName.substring(1);
                            // 获取set方法
                            Method setMethod = aClass.getDeclaredMethod(setMethodName, field.getType());
                            // 获取具体的值
                            // 此处的String需要分类讨论，可能是int，也有可能是String。。
                            String value = property.attributeValue("value");
                            Object actualValue = null;
                            String ref = property.attributeValue("ref");
                            if (value != null){
                                // 说明值是简单类型
                                // 难以确定invoke后面的值的类型
                                // 框架声明：只支持简单类型
                                // byte short int long float double boolean char + 包装类

                                // 获取属性类型名
                                String properTypeSimpleName = field.getType().getSimpleName(); // .getName() -> java.lang.name
                                switch (properTypeSimpleName){
                                    case "byte" -> actualValue = Byte.parseByte(value);
                                    case "short"-> actualValue = Short.parseShort(value);
                                    case "int"-> actualValue = Integer.parseInt(value);
                                    case "long"-> actualValue = Long.parseLong(value);
                                    case "float"-> actualValue = Float.parseFloat(value);
                                    case "double"-> actualValue = Double.parseDouble(value);
                                    case "boolean"-> actualValue = Boolean.parseBoolean(value);
                                    case "char"-> actualValue = value.charAt(0);
                                    case "Byte"-> actualValue = Byte.valueOf(value);
                                    case "Short"-> actualValue = Short.valueOf(value);
                                    case "Integer"-> actualValue = Integer.valueOf(value);
                                    case "Long"-> actualValue = Long.valueOf(value);
                                    case "Float"-> actualValue = Float.valueOf(value);
                                    case "Double"-> actualValue = Double.valueOf(value);
                                    case "Boolean"-> actualValue = Boolean.valueOf(value);
                                    case "Character"-> actualValue = Character.valueOf(value.charAt(0));
                                    case "String"-> actualValue = value;
                                }
                            }
                            if (ref != null){
                                // 说明值是非简单类型
                                // 调用set方法
                                setMethod.invoke(singletonObjects.get(id), singletonObjects.get(ref));
                            }
                            // 调用set方法
                            setMethod.invoke(singletonObjects.get(id), actualValue);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }

            });
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Object getBean(String beanName) {
        return null;
    }
}
