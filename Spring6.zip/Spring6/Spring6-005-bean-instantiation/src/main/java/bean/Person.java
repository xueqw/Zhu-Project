package bean;

public class Person {
    public Person(){
        System.out.println("无参构造执行");
    }
}
