package bean;

public class GunFactory {
    public Gun get(){
        return new Gun();
    }
}
