package bean;

/**
 * 简单工厂模式中的工厂类角色
 */
public class StarFactory {
    public static Star get(){
        //实际创建是我们负责new的对象
        return new Star();
    }
}
