package bean;

/**
 * 明星类
 */
public class Star {
    public Star(){
        System.out.println("Star的无参构造执行");
    }
}
