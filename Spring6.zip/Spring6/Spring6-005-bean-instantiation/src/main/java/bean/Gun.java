package bean;

/**
 * 工厂方法模式中的具体产品角色
 */
public class Gun {
    public Gun(){
        System.out.println("gun的无参方法执行");
    }
}
