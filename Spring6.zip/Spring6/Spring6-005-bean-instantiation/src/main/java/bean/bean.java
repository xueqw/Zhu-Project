package bean;

public class bean {
    public void SpringBean(){
        System.out.println("无参方法执行");
    }
}
