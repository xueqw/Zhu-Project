package client;

import service.OrderService;
import service.OrderServiceImpl;
import service.TimeInvocationHandler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class client {
    public static void main(String[] args) {
        OrderService target = new OrderServiceImpl();
        OrderService ProxyObj = (OrderService) Proxy.newProxyInstance(target.getClass().getClassLoader(),
                target.getClass().getInterfaces(),
                (proxy, method, args1) -> {
                    System.out.println("增强");
                    long start = System.currentTimeMillis();
                    method.invoke(target, args1);
                    long end = System.currentTimeMillis();
                    return null;
                });
        ProxyObj.generate();
    }
}
