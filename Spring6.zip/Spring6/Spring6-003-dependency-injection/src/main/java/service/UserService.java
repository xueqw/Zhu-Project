package service;

import org.powernode.dao.UserDao;

public class UserService {
    private UserDao userDao;

    //自己写一个set方法，不使用IDEA工具生成的
    public void setMySQLUserDao(UserDao xyz){
        this.userDao = xyz;
    }

    public void saveUser(){
        userDao.insert();
    }
}
