package org.powernode.dao;

public class VipDao {
    public void insert(){
        System.out.println("数据库正在保存用户信息");
    }
}
