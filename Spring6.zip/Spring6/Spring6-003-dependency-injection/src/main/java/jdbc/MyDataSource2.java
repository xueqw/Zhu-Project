package jdbc;

public class MyDataSource2 {
}
