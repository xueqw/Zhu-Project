package jdbc;

public class MyDataSource1 {
}
