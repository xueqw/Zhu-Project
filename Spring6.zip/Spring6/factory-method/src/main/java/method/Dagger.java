package method;

public class Dagger extends Weapon{
    @Override
    public void attack() {
        System.out.println("砍丫的");
    }
}
