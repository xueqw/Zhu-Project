package method;

public abstract class WeaponFactory {
    /**
     * 此方法非静态了，变成抽象方法
     * @return
     */
    public abstract Weapon get();
}
