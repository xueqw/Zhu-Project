package com.powernode.spring6.test;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {
    @Test
    public void testBeginInitBean(){
        new ClassPathXmlApplicationContext("Spring.xml");
        Logger logger = LoggerFactory.getLogger(test.class);

        logger.debug("我是一条调试信息");

    }

    @Test
    public void testFirstSpringCode(){
        // 第一步：获取Spring对象
        // applicationContext 是一个接口，有很多实现类，如ClassPathXmlApplicationContext
        // ClassPathXmlApplicationContext 专门从类路径中加载spring配置文件的Spring上下文对象
        // 一启动new出所有的bean，启动了spring容器，将bean加载进spring容器中
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        // 第二步：根据bean的id获取对象
        Object userBean = applicationContext.getBean("userBean");
        System.out.println(userBean);
    }
}
