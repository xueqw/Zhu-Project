package org.powernode.dao;

public class UserDaoImplForMySQL {
}
