package com.mybatis.spring6.bean;

public class User {

}
