package factory;

public class WeaponFactory {
    /**
     * 静态方法。要获取什么产品看参数
     * @param weaponType
     * @return
     */
    public static Weapon get(String weaponType){
        if ("TANK".equals(weaponType)){
            return new Tank();
        }else if ("DAGGER".equals(weaponType)){
            return new Dagger();
        }else if ("FIGHTER".equals(weaponType)){
            return new Fighter();
        }else {
            throw new RuntimeException("不支持该武器的生产");
        }
    }
}
