package bean;

/*
* 第一步：实例化Bean
* 第二步：给Bean赋值
* 第三步：初始化Bean（Bean的init方法）
* 第四步：使用Bean
* 第五步：destroy方法
*/
public class User {
    private String name;

    public User(String name) {
        this.name = name;
    }

    public User(){
        System.out.println("第一步 无参构造方法执行");
    }

    public void initBean(){
        System.out.println("第三步 初始化Bean");
    }

    public void destroyBean(){
        System.out.println("第五步 销毁Bean");
    }

    public void setName(String name) {
        System.out.println("第二步 初始化bean");

    }
}
