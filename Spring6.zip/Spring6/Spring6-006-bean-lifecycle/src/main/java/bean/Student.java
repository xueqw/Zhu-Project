package bean;

public class Student {
}
