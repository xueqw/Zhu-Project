import bean.Student;
import bean.User;
import org.junit.Test;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanLifecycleTest {
    @Test
    public void testRegisterBean(){
        Student student = new Student();
        DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
        factory.registerSingleton("student",student);
    }

    @Test
    public void testBeanLifecycleFive(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        User user = applicationContext.getBean("user",User.class);
        System.out.println("第四步：使用Bean：" + user);

        ClassPathXmlApplicationContext context = (ClassPathXmlApplicationContext) applicationContext;
        context.close();
    }
}
