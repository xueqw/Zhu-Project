package bean;

public class SpringBean {
}
