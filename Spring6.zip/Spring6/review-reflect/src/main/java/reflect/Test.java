package reflect;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchFieldException {
        Class<?> aClass = Class.forName("reflect.User");
        //根据属性名获取属性类型
        Field setAge = aClass.getDeclaredField("setAge");
        Method declaredMethod = aClass.getDeclaredMethod("setAge", setAge.getType());
        Object o = aClass.newInstance();
        declaredMethod.invoke(o,25);
        System.out.println(o);
    }
}
