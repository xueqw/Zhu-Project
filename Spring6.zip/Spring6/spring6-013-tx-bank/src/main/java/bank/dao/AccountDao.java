package bank.dao;

import bank.pojo.Account;

// 只执行SQL语句，没有业务逻辑
public interface AccountDao {
    Account selectByActno(String actno);

    int update(Account act);

    int insert(Account act);
}
