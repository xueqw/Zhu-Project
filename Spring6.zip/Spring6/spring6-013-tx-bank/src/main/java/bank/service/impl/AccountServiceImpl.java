package bank.service.impl;

import bank.dao.AccountDao;
import bank.pojo.Account;
import bank.service.AccountService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("accountService")
public class AccountServiceImpl implements AccountService {
    @Resource(name = "accountDao")
    private AccountDao accountDao;


    @Override
    public void transfer(String fromActno, String toActno, double money) {
        Account fromAct = accountDao.selectByActno(fromActno);
        if (fromAct.getBalance() < money){
            throw new RuntimeException("余额不足！！！");
        }
        // 余额充足
        Account toAct = accountDao.selectByActno(toActno);


        fromAct.setBalance(fromAct.getBalance()-money);
        toAct.setBalance(toAct.getBalance()+money);


        accountDao.update(fromAct);
        accountDao.update(toAct);
    }

    @Resource(name = "accountService")
    private AccountService accountService;

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void save(Account act) {
        // 这里调用dao的insert方法
        // accountDao的参数在测试中定义
        accountDao.insert(act);

        Account account2 = new Account("act-004",1000.0);
        accountService.save(account2);
    }
}
