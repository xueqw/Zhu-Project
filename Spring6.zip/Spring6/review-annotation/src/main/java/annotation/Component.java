package annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
// 标记注解的注解，叫元注解
// 以下表示可以出现在类上，属性上
@Target(value = {ElementType.TYPE,ElementType.FIELD})
// @Retention(RetentionPolicy.SOURCE) // 只保留在源文件里
@Retention(RetentionPolicy.RUNTIME)
public @interface Component {
    String value();
}
