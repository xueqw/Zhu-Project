package client;

import annotation.Component;

public class ReflectionAnnotationTest1 {
    public static void main(String[] args) throws Exception{
        Class<?> aClass = Class.forName("bean.User");
        if (aClass.isAnnotationPresent(Component.class)) {
            Component annotation = aClass.getAnnotation(Component.class);
            System.out.println(annotation.value());
        }
    }
}
