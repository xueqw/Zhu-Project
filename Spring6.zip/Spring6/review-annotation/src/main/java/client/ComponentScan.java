package client;

import annotation.Component;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ComponentScan {
    public static void main(String[] args) {
        HashMap<String, Object> beanMap = new HashMap<>();
        // 扫描包下所有的类，实例化对象，当类上有@Component对象时，实例化并放到map集合里
        String packageName = "bean";
        //这个'.'正则表达式代表任意字符。需要转义
        String packagePath = packageName.replaceAll("\\.", "/");
        System.out.println(packagePath);
        URL resource = ClassLoader.getSystemClassLoader().getResource(packagePath);
        String path = resource.getPath();
        // 获取一个绝对路径下的所有文件
        File file = new File(path);
        File[] files = file.listFiles();
        Arrays.stream(files).forEach(file1 -> {
            try {
                String className = packageName + "." + file1.getName().split("\\.")[0];
                Class<?> aClass = Class.forName(className);
                // 判断类上是否有此注解
                if (aClass.isAnnotationPresent(Component.class)) {
                    Component annotation = aClass.getAnnotation(Component.class);
                    String id = annotation.value();
                    Object obj = aClass.newInstance();
                    beanMap.put(id, obj);

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        System.out.println(beanMap);
    }
}
