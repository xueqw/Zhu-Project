package bean;

import annotation.Component;

@Component("userBean")
public class User {
}
