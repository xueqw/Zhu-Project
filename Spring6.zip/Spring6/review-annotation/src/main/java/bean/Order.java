package bean;

import annotation.Component;

@Component("orderBean")
public class Order {
}
