package bean;

public class Vip {
}
