package proxy.service;

public class OrderServiceImpl implements OrderService{ // 目标对象

    /**
     * 项目经理提出一个新的需求：统计所有业务方法的耗时
     * 解决方法一：直接添加统计耗时的方法
     * 缺点一：不符合OCP原则
     * 缺点二：相同的方法使用太多遍
     *
     * 解决方法二：编写业务类的子类，让子类继承业务类并重写
     * 缺点：耦合度过高
     *
     * 解决方法三：代理模式
     * 优点一：解决了OCP问题
     * 优点二：降低了耦合度
     * 缺点：代理类太多了。每个接口都要对应代理类，不好维护
     * 怎么解决类爆炸问题？ -> 使用动态代理来解决
     * 还是代理模式，但添加了字节码生成技术。在内存中动态生成字节码代理类
     */
    @Override
    public void generate() {
        // 模拟生成订单的耗时
        try {
            Thread.sleep(1234);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("订单已生成");
    }

    @Override
    public void modify() {
        try {
            Thread.sleep(456);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("订单已修改");
    }

    @Override
    public void detail() {
        try {
            Thread.sleep(789);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("请看订单详情");

    }
}
