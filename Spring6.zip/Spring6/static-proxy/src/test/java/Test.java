import proxy.service.OrderService;
import proxy.service.OrderServiceImpl;
import proxy.service.OrderServiceProxy;

public class Test {
    public static void main(String[] args) {
        OrderService target = new OrderServiceImpl();
        OrderService proxy = new OrderServiceProxy(target);
    }
}
