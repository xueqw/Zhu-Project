package spring6.service;

import org.springframework.stereotype.Service;

@Service
public class OrderService {
    public void generate(){
        System.out.println("正在生成订单");
    }

    public void cancel(){
        System.out.println("正在取消生成订单");
    }
}
