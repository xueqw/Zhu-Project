package proxy.client;

import proxy.service.OrderService;
import proxy.service.OrderServiceImpl;
import proxy.service.TimerInvocationHandler;

import java.lang.reflect.Proxy;

public class Client {
    public static void main(String[] args) {
        OrderService target = new OrderServiceImpl();
        // 类加载器 代理类要实现的接口 调用处理器
        /**
         * newProxyInstance 新建代理对象
         * 一、通过这种方法可以创建代理对象
         * 本质上newProxyInstance做了两件事
         * 1.在内存中动态生成了一个代理类的字节码class
         * 2.new对象了。通过内存中生成的代理类的代码实例化了代理对象
         * 二、关于newProxyInstance方法的三个重要的参数
         * 1.类加载器 在内存中的字节码也是class文件，要执行也得先加载到内存中，需要类加载器
         * 而且类加载器必须和目标类的是同一个
         * 2
         */
        OrderService proxyObj = (OrderService) Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), new TimerInvocationHandler(target));
        String name = proxyObj.getName();
        System.out.println(name);
    }
}
