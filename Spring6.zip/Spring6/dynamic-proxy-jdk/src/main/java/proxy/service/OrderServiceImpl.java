package proxy.service;

public class OrderServiceImpl implements OrderService{ // 目标对象
    @Override
    public String getName() {
        System.out.println("getName()方法执行了");
        return "张三";
    }

    @Override
    public void generate() {
        // 模拟生成订单的耗时
        try {
            Thread.sleep(1234);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("订单已生成");
    }

    @Override
    public void modify() {
        try {
            Thread.sleep(456);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("订单已修改");
    }

    @Override
    public void detail() {
        try {
            Thread.sleep(789);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("请看订单详情");

    }
}
