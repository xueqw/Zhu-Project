package spring6.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public class UserService { // 目标类
    public void login(){ // 目标方法
        System.out.println("系统正在进行身份认证");
    }
}
