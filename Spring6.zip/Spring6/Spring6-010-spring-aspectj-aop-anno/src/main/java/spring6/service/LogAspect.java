package spring6.service;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component("logAspect")
@Aspect // 切面类需要标注aspect实现
public class LogAspect { // 切面

    // 切面 = 通知 + 切点
    // 这里通知以方法的形式出现
    // @Before表示前置通知
    @Before("execution(* spring6.service..*(..))")
    public void inforce(){
        System.out.println("我是一个通知，我是一段增强代码。。");
    }

}
